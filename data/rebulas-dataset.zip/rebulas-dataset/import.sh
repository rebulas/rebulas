#!/bin/sh

for f in *.txt
do
        echo "Submitting $f"
        curl -XPOST --user pavel:pavel localhost:3001/apiv2/ideas --data-binary @$f 
        echo ""
        sleep 1
done
